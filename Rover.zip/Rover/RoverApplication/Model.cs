﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoverApplication
{
    class Rover
    {
        internal string Name { get; set; }
        internal int CoordinateX { get; set; } = 0;
        internal int CoordinateY { get; set; } = 0;
        internal Directions Direction { get; set; } = Directions.North;
    }

    class Rovers
    {
        internal Rover Rover { get; set; }
        internal bool Active { get; set; } = false;
    }

    class Grid
    {
        internal int MaxX { get; set; } = 0;
        internal int MaxY { get; set; } = 0;
        internal bool DisplayGrid { get; set; } = false;
    }
}
