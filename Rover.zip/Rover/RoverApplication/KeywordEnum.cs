﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoverApplication
{
    internal enum Directions
    {
        North = 'N',
        East = 'E',
        South = 'S',
        West = 'W'
    }

    internal enum Input
    {
        Move = 'M',
        Right = 'R',
        Left = 'L'
    }

    internal enum Commands
    {
        Exit,
        Settings
    }

    internal enum Settings
    {
        CreateRover,
        DisplayGrid
    }

    internal enum Validation
    {
        [Description("Invalid Grid Input.")]
        Grid,
        [Description("Invalid Location Input.")]
        Location,
        [Description("Invalid Rover Input.")]
        Rover,
        [Description("Invalid Setting Input.")]
        Settings
    }
}
