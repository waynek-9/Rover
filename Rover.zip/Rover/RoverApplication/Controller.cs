using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RoverApplication
{
    class Controller
    {
        private static bool _isValid = true;

        internal static bool IsValid
        {
            get { return _isValid; }
            set
            {
                _isValid = value;
                if (!_isValid)
                {
                    Console.WriteLine("\n\r{0}", errorMessage);

                    Console.WriteLine("Would you like to restart the NASA Mars Rover Expedition Application?");
                    Console.WriteLine("(Y/N)");
                    if (Console.ReadKey().Key == ConsoleKey.Y)
                        System.Diagnostics.Process.Start(Assembly.GetExecutingAssembly().Location);

                    Console.WriteLine();
                    Environment.Exit(0);
                }
            }
        }

        internal static string errorMessage = "";

        internal static List<Rovers> rovers;
        internal static Grid grid;

        internal static List<char> cardinal = new List<char> { 'N', 'E', 'S', 'W' };

        //Fix ordering to be viable
        //internal static List<char> cardinal2 = Enum.GetValues(typeof(Directions)).
        //    Cast<Directions>().Select(x => (char)x).ToList();

        internal Controller()
        {
            rovers = new List<Rovers>
            {
                new Rovers() { Rover = new Rover { Name = "Alpha" }, Active = true },
                new Rovers() { Rover = new Rover { Name = "Omega" }, Active = false }
            };

            grid = new Grid();
        }

        internal static void MoveRover()
        {
            bool isValid = true;
            Rover rover = rovers.Where(x => x.Active).First().Rover;

            switch (rover.Direction)
            {
                case Directions.North:
                    if (rover.CoordinateY + 1 <= grid.MaxY)
                        rover.CoordinateY++;
                    else
                        isValid = false;
                    break;
                case Directions.East:
                    if (rover.CoordinateX + 1 <= grid.MaxX)
                        rover.CoordinateX++;
                    else
                        isValid = false;
                    break;
                case Directions.South:
                    if (rover.CoordinateY - 1 >= 0)
                        rover.CoordinateY--;
                    else
                        isValid = false;
                    break;
                case Directions.West:
                    if (rover.CoordinateX - 1 >= 0)
                        rover.CoordinateX--;
                    else
                        isValid = false;
                    break;
                default:
                    break;
            }

            if (!isValid)
            {
                errorMessage = string.Format("Rover {0} fell off the plateau.", rover.Name);
                IsValid = false;
            }
        }

        internal static void RoverInput(Input mark)
        {
            Rover rover = rovers.Where(x => x.Active).First().Rover;

            int index = cardinal.IndexOf((char)rover.Direction);

            switch (mark)
            {
                case Input.Move:
                    MoveRover();
                    break;
                case Input.Left:
                    rover.Direction = index == 0 ?
                        (Directions)cardinal.ElementAt(index + cardinal.Count - 1) :
                        (Directions)cardinal.ElementAt(index - 1);
                    break;
                case Input.Right:
                    rover.Direction = index == cardinal.Count - 1 ?
                        (Directions)cardinal.ElementAt(index - cardinal.Count + 1) :
                        (Directions)cardinal.ElementAt(index + 1);
                    break;
                default:
                    break;
            }
        }


        internal static void ValidateInput(string userInput, Validation mark)
        {
            switch (mark)
            {
                case Validation.Grid:
                    errorMessage = "Invalid Grid Input.";

                    IsValid = userInput.Contains(" ");

                    List<string> gridArray = userInput.Split(' ').ToList();
                    gridArray.Remove(" ");
                    
                    IsValid = gridArray.Count == 2 & gridArray.All(x => int.TryParse(x, out int result) && int.Parse(x) >= 0);

                    break;
                case Validation.Location:
                    errorMessage = "Invalid Location Input.";

                    IsValid = userInput.Contains(" ");

                    List<string> locationArray = userInput.Split(' ').ToList();
                    locationArray.Remove(" ");

                    IsValid = locationArray.Count == 3 & 
                        locationArray.Take(2).All(x => int.TryParse(x, out int result) && int.Parse(x) >= 0) & 
                        cardinal.Contains(locationArray.Skip(2).First().ToUpper().ToCharArray()[0]);

                    break;
                case Validation.Rover:
                    errorMessage = "Invalid Rover Input.";

                    List<char> roverList = Enum.GetValues(typeof(Input)).Cast<Input>().Select(x => (char)x).ToList();
                    List<char> inputList = new List<char>();
                    inputList.AddRange(userInput.ToUpper());
                    IsValid = inputList.All(x => roverList.Contains(x));

                    break;
                case Validation.Settings:
                    errorMessage = "Invalid Setting Input.";

                    List<string> settingsList = Enum.GetValues(typeof(Settings)).Cast<Settings>().Select(x => x.ToString().ToUpper()).ToList();
                    IsValid = settingsList.Contains(userInput.ToUpper());

                    break;
                default:
                    break;
            }
        }
    }
}
