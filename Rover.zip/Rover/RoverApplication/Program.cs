using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoverApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller controller = new Controller();

            Console.WriteLine("Welcome to the NASA Mars Rover Expedition Application.");

            Console.WriteLine("Please enter grid dimensions.");
            Console.WriteLine("Ex. 5 5");

            SetGrid(Console.ReadLine());

            foreach (Rover rover in Controller.rovers.Select(x => x.Rover))
            {
                Console.WriteLine("Please enter a location for {0}.", rover.Name);
                Console.WriteLine("Ex. 1 2 N");

                SetLocation(Console.ReadLine(), rover);
            }

            while (Controller.IsValid)
            {
                SetHeader();

                if (Controller.grid.DisplayGrid)
                    DisplayGrid();

                Console.WriteLine("\r\nPlease enter input for rover {0}.", 
                    Controller.rovers.Where(x => x.Active).First().Rover.Name);
                Console.WriteLine("Valid characters: M R L");
                string userInput = Console.ReadLine();

                if (userInput.ToUpper() == Commands.Exit.ToString().ToUpper())
                    break;
                else if (userInput.ToUpper() == Commands.Settings.ToString().ToUpper())
                {
                    SetSettings();
                    continue;
                }

                ProcessRoverInput(userInput);
            }

            Console.Write("\r\nDone");
            Console.ReadKey();
        }

        internal static void SetGrid(string userInput)
        {
            Controller.ValidateInput(userInput, Validation.Grid);

            Controller.grid.MaxX = int.Parse(userInput.Split(' ')[0]);
            Controller.grid.MaxY = int.Parse(userInput.Split(' ')[1]);
        }

        internal static void SetLocation(string userInput, Rover rover)
        {
            Controller.ValidateInput(userInput, Validation.Location);

            rover.CoordinateX = int.Parse(userInput.Split(' ')[0]);
            rover.CoordinateY = int.Parse(userInput.Split(' ')[1]);
            rover.Direction = (Directions)userInput.Split(' ')[2].ToUpper().ToCharArray()[0];
        }

        internal static void SetHeader()
        {
            Console.Clear();

            Rover current = Controller.rovers.Where(x => x.Active).First().Rover;

            Console.WriteLine("Grid Size: {0} x {1}", Controller.grid.MaxX, Controller.grid.MaxY);

            Console.WriteLine("Current Rover: {0}", current.Name);
            Console.WriteLine("Current Coordinates: {0}, {1}", current.CoordinateX, current.CoordinateY);
            Console.WriteLine("Current Direction: {0}", current.Direction);
        }

        internal static void ProcessRoverInput(string userInput)
        {
            Controller.ValidateInput(userInput, Validation.Rover);

            List<char> inputArray = new List<char>();
            inputArray.AddRange(userInput.ToUpper());
            
            inputArray.ForEach(x => Controller.RoverInput((Input)x));

            int index = Controller.rovers.IndexOf(Controller.rovers.Where(x => x.Active).First());

            Controller.rovers[index].Active = false;
            Controller.rovers[index == Controller.rovers.Count - 1 ? 
                index - Controller.rovers.Count + 1 :
                index + 1].Active = true;
        }

        internal static void SetSettings()
        {
            Console.Clear();

            Console.WriteLine("Please enter the name of the setting you would like to enable.");
            for (int i = 0; i < Enum.GetNames(typeof(Settings)).Length; i++)
            {
                string setting = Enum.GetNames(typeof(Settings))[i];
                Console.WriteLine("{0}. {1}{2}", i + 1, setting,
                    setting == Settings.DisplayGrid.ToString() ? 
                        Controller.grid.DisplayGrid ? ": ON" : ": OFF" 
                    : "");
            }

            string userInput = Console.ReadLine();

            Controller.ValidateInput(userInput, Validation.Settings);

            if (userInput.ToUpper() == Settings.CreateRover.ToString().ToUpper())
            {
                CreateRovers();
            }
            else if (userInput.ToUpper() == Settings.DisplayGrid.ToString().ToUpper())
                Controller.grid.DisplayGrid = !Controller.grid.DisplayGrid;
        }

        internal static void CreateRovers()
        {
            Controller.rovers = new List<Rovers>();
            string name = "";
            string location = "";

            do
            {
                Console.WriteLine("\r\nPlease enter a name for your rover.");
                name = Console.ReadLine();

                Console.WriteLine("Please enter a location for {0}.", name);
                Console.WriteLine("Ex. 1 2 N");
                location = Console.ReadLine();

                Controller.ValidateInput(location, Validation.Location);

                Controller.rovers.Add(new Rovers()
                {
                    Rover = new Rover
                    {
                        Name = name,
                        CoordinateX = int.Parse(location.Split(' ')[0]),
                        CoordinateY = int.Parse(location.Split(' ')[1]),
                        Direction = (Directions)location.Split(' ')[2].ToUpper().ToCharArray()[0]
                    },
                    Active = !Controller.rovers.Any(x => x.Active)
                });
                Console.WriteLine("Would you like to setup another rover?");
                Console.WriteLine("(Y/N)");
            } while (Console.ReadKey().Key == ConsoleKey.Y);
        }

        internal static void DisplayGrid()
        {
            string grid = "\n\r";

            Rover current = Controller.rovers.Where(x => x.Active).First().Rover;

            for (int y = 0; y < Controller.grid.MaxY + 1; y++)
            {
                grid += "|";

                for (int x = 0; x < Controller.grid.MaxX + 1; x++)
                {
                    grid += current.CoordinateX == x && current.CoordinateY == Controller.grid.MaxY - y ?
                        " X " : " _ ";
                }

                grid += "|\n\r";
            }

            Console.WriteLine(grid);
        }
    }
}
